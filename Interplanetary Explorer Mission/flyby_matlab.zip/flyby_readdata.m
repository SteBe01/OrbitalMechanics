function [fid, jdtdbi1, ddays1, jdtdbi2, ddays2, jdtdbi3, ddays3, ...
    ip1, ip2, ip3, fbalt_lwr, fbalt_upr, boev, otype] = flyby_readdata(filename)

% read flyby simulation definition data file

% NOTE: all angular elements are returned in radians

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

dtr = pi / 180.0;

% open data file

fid = fopen(filename, 'r');

% check for file open error

if (fid == -1)
    
    clc; home;
    
    fprintf('\n\n error: cannot find this file!!');
    
    pause
    
    return;
    
end

% read 125 lines of data file

for i = 1:1:125
    
    cline = fgetl(fid);
    
    switch i
        
        case 12
            
            % departure calendar date
            
            tl = size(cline);
            
            ci = strfind(cline, ',');
            
            % extract month, day and year
            
            month = str2double(cline(1:ci(1)-1));
            
            day = str2double(cline(ci(1)+1:ci(2)-1));
            
            year = str2double(cline(ci(2)+1:tl(2)));
            
            jdtdbi1 = julian(month, day, year);
            
        case 15
            
            % search boundary for departure date (days)
            
            ddays1 = str2double(cline);
            
        case 30
            
            % departure planet
            
            ip1 = str2double(cline);
            
        case 37
            
            % flyby calendar date
            
            tl = size(cline);
            
            ci = strfind(cline, ',');
            
            % extract month, day and year
            
            month = str2double(cline(1:ci(1)-1));
            
            day = str2double(cline(ci(1)+1:ci(2)-1));
            
            year = str2double(cline(ci(2)+1:tl(2)));
            
            jdtdbi2 = julian(month, day, year);
            
        case 40
            
            % search boundary for flyby date (days)
            
            ddays2 = str2double(cline);
            
        case 55
            
            % flyby planet
            
            ip2 = str2double(cline);
            
        case 58
            
            % lower bound for flyby altitude (kilometers)
            
            fbalt_lwr = str2double(cline);
            
        case 61
            
            % upper bound for flyby altitude (kilometers)
            
            fbalt_upr = str2double(cline);
            
        case 68
            
            % arrival calendar date
            
            tl = size(cline);
            
            ci = strfind(cline, ',');
            
            % extract month, day and year
            
            month = str2double(cline(1:ci(1)-1));
            
            day = str2double(cline(ci(1)+1:ci(2)-1));
            
            year = str2double(cline(ci(2)+1:tl(2)));
            
            jdtdbi3 = julian(month, day, year);
            
        case 71
            
            % search boundary for arrival date (days)
            
            ddays3 = str2double(cline);
            
        case 87
            
            % arrival celestial body
            
            ip3 = str2double(cline);
            
        case 99
            
            % type of trajectory optimization
            
            otype = str2double(cline);
            
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % read asteroid/comet orbital elements
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
        case 110
            
            % TDB date of perihelion passage
            
            tl = size(cline);
            
            ci = strfind(cline, ',');
            
            % extract month, day and year
            
            month = str2double(cline(1:ci(1)-1));
            
            day = str2double(cline(ci(1)+1:ci(2)-1));
            
            year = str2double(cline(ci(2)+1:tl(2)));
            
        case 113
            
            % perihelion distance (astronomical units)
            
            boev(1) = str2double(cline);
            
        case 116
            
            % orbital eccentricity (non-dimensional)
            
            boev(2) = str2double(cline);
            
        case 119
            
            % orbital inclination (radians)
            
            boev(3) = dtr * str2double(cline);
            
        case 122
            
            % argument of perihelion (radians)
            
            boev(4) = dtr * str2double(cline);
            
        case 125
            
            % longitude of the ascending node (radians)
            % NOTE: this is celestial longitude, NOT RAAN
            
            boev(5) = dtr * str2double(cline);
            
    end
    
end

% TDB julian date of perihelion passage

boev(6) = julian(month, day, year);

fclose(fid);

