function [y, g] = fbyfunc(x)

% patched-conic gravity assist mission
% constraints and objective function

% required by flyby_matlab.m

% Orbital Mechanics with MATLAB

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global smu ip1 ip2 ip3 jdtdb0

global pmu rep fbalt

global dv_launch dvm_launch dv_arrival dvm_arrival

global fbsma fbecc fbrp

global c3launch rito1 vito1 rito2 vito2

global otype dvh vinfm_in vinfm_out

global vinf_in vinf_out rinf_in

% tdb Julian dates of current solution

jdtdb1 =  jdtdb0 + x(1);

jdtdb2 =  jdtdb0 + x(2);

jdtdb3 =  jdtdb0 + x(3);

% posigrade transfer

direct = 1;

% less than one rev transfer

revmax = 0;

% compute heliocentric state vector of departure planet at launch (km & km/sec)

[rp1, vp1] = p2000(ip1, jdtdb1);

% compute heliocentric state vector of flyby planet at flyby (km & km/sec)

[rp2, vp2] = p2000(ip2, jdtdb2);

% compute heliocentric state vector of arrival planet at arrival (km & km/sec)

[rp3, vp3] = p2000(ip3, jdtdb3);

% solve Lambert's problem for first leg

tof1 = 86400.0 * (jdtdb2 - jdtdb1);

for i = 1:1:3
    
    sv1(i) = rp1(i);
    
    sv1(i + 3) = vp1(i);
    
    sv2(i) = rp2(i);
    
    sv2(i + 3) = vp2(i);
    
end

[vito1, vfto1] = glambert(smu, sv1, sv2, direct * tof1, revmax);

% load initial and final heliocentric position vectors for this leg

rito1 = rp1';

rfto1 = rp2';

% compute launch heliocentric delta-v vector, magnitude and energy

dv_launch = vito1' - vp1;

dvm_launch = norm(dv_launch);

c3launch = dvm_launch * dvm_launch;

% calculate incoming v-infinity vector and magnitude (km/sec)

vinf_in = vfto1' - vp2;

vinfm_in = norm(vinf_in);

rinf_in = rfto1' - rp2;

% solve Lambert's problem for second leg

tof2 = 86400.0 * (jdtdb3 - jdtdb2);

for i = 1:1:3
    
    sv1(i) = rp2(i);
    
    sv1(i + 3) = vp2(i);
    
    sv2(i) = rp3(i);
    
    sv2(i + 3) = vp3(i);
    
end

[vito2, vfto2] = glambert(smu, sv1, sv2, direct * tof2, revmax);

% load initial and final heliocentric position vectors for this leg

rito2 = rp2';

% heliocentric speed change due to flyby (kilometer/second)

dv = vito2 - vfto1;

dvh = norm(dv);

% calculate outgoing v-infinity vector and magnitude (kilometer/second)

vinf_out = vito2' - vp2;

vinfm_out = norm(vinf_out);

% determine flyby angle (radians)

v1crossv2 = cross(vinf_in, vinf_out);

v1crossv2m = norm(v1crossv2);

phi1 = 0.5 * pi + 0.5 * asin(v1crossv2m / (vinfm_in * vinfm_out));

% calculate planet-centered hyperbolic orbital elements

fbecc = -1.0 / cos(phi1);

fbsma = - pmu(ip2) / (vinfm_in * vinfm_in);

fbrp = fbsma * (1.0 - fbecc);

% compute flyby altitude (kilometers)

fbalt = fbrp - rep(ip2);

% compute arrival heliocentric delta-v vector and magnitude

dv_arrival = vp3 - vfto2';

dvm_arrival = norm(dv_arrival);

% load scalar objective function

switch otype
    
case 1
    
   % launch delta-v (kilometer/second)
   
   f = dvm_launch;
   
case 2
    
   % arrival delta-v (kilometers/second)
   
   f = dvm_arrival;
   
case 3
    
   % launch + arrival delta-v (kilometers/second)
   
   f = dvm_launch + dvm_arrival;
   
end

% load objective function

y(1) = f;

% load mission constraints (flyby altitude and v-infinity matching)

y(2) = fbalt;

y(3) = vinfm_in - vinfm_out;

y = y';

% no derivatives

g = [];
